package com.hand.eurekaribbonclient.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;


@Configuration
public class RibbonConfig {
        /**在调用 eureka-client的API 接口“／hello ”时希望做到轮流访 问这两个实例，这时就需要将 RestTemplate和Ribbon相结合，进行负载均衡。
         * 通过查阅官方文档，可以知道如何将它们结合在 起，只需要在程序的 IoC 容器中注入一个
         * restTemplate 的 Bean 并在这个 Bean 上加上@LoadBalanced 注解，此时 RestTemplate 就结合了
         * Ribbon 开启了负载均衡功能，
         */
        @Bean
        @LoadBalanced
        RestTemplate restTemplate(){
            return new RestTemplate();
        }
    }
