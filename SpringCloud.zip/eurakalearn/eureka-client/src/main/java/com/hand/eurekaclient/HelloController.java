package com.hand.eurekaclient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @Value("${server.port}")
    private String port;
    @GetMapping("/Hello")
    public String home(@RequestParam String name) {
        return "欢迎 "+ name +" 来到Eureka-Server:" + port;
    }
}
