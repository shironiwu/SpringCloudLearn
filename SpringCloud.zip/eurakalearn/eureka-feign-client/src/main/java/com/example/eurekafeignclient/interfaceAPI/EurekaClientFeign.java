package com.example.eurekafeignclient.interfaceAPI;

import com.example.eurekafeignclient.config.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

//@FeignClient(value = "eureka-client",configuration = FeignConfig.class)
//熔断测试
@FeignClient(value = "eureka-client",configuration = FeignConfig.class,fallback = com.example.eurekafeignclient.interfaceAPI.HelloHystrix.class)
public interface EurekaClientFeign {
    @GetMapping(value = "/Hello")
    String sayHelloFromClientEureka(@RequestParam(value = "name") String name);

}
