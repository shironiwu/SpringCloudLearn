package com.example.eurekafeignclient.config;

import com.netflix.hystrix.contrib.metrics.eventstream.HystrixMetricsStreamServlet;
import feign.Retryer;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static java.util.concurrent.TimeUnit.SECONDS;
/**
 * 注入该Bean 之后， Feign 在远程调用失败后会进行重试。
 * @return
 */
@Configuration
public class FeignConfig {
    @Bean
    public Retryer feignRetryer(){
        return new Retryer.Default(100,SECONDS.toMillis(1),5);
    }
    @Bean
    public ServletRegistrationBean hystrixMetricsStreamServlet() {
        HystrixMetricsStreamServlet hystrixMetricsStreamServlet = new HystrixMetricsStreamServlet();
        ServletRegistrationBean registration = new ServletRegistrationBean(hystrixMetricsStreamServlet);
        registration.setLoadOnStartup(1);
        registration.addUrlMappings("/hystrix.stream");
        registration.setName("HystrixMetricsStreamServlet");
        return registration;
    }
}
