package com.example.eurekafeignclient.service;

 import com.example.eurekafeignclient.interfaceAPI.EurekaClientFeign;
 import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HelloService {
    @Autowired
    EurekaClientFeign eurekaClientFeign;

    public String sayHello(String name) {
        return eurekaClientFeign.sayHelloFromClientEureka(name);
    }
}
