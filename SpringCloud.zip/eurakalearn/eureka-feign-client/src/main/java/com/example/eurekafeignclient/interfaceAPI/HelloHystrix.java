package com.example.eurekafeignclient.interfaceAPI;

import com.example.eurekafeignclient.interfaceAPI.EurekaClientFeign;
import org.springframework.stereotype.Component;

@Component
public class HelloHystrix implements EurekaClientFeign {
    @Override
    public String sayHelloFromClientEureka(String name) {
        return "hello," + name + "sorry,error!";
    }
}
