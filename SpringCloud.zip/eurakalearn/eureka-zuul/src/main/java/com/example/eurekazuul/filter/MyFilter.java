package com.example.eurekazuul.filter;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import static org.springframework.cloud.netflix.zuul.filters.support.FilterConstants.PRE_TYPE;

@Component
public class MyFilter extends ZuulFilter {
    private static Logger log = LoggerFactory.getLogger(MyFilter.class);

    @Override
    public String filterType() {
//        System.out.println("===============>filterType");
        return PRE_TYPE;
    }

    @Override
    public int filterOrder() {
//        System.out.println("===============>filterOrder");
        return 0;
    }

    /**
     * 过滤器的开关 为 true ，则执行 run()方法：为 false ，则 不执行 run ()方法
     *
     * @return
     */
    @Override
    public boolean shouldFilter() {
//      获取上一个过滤器返回的结果，为true则说明上一个过滤器成功，需要进入当前过滤器，如果为false 则无需进入下面的过滤器逻辑
//        RequestContext ctx = RequestContext.getCurrentContext();
//        return (boolean)ctx.get("isSuccess");
//        System.out.println("===============>shouldFilter");
        return true;
    }

    /**
     * 过滤器的具体逻辑
     *
     * @return
     * @throws ZuulException
     */
    @Override
    public Object run() throws ZuulException {
//        System.out.println("===============>run");
        RequestContext ctx = RequestContext.getCurrentContext();
        HttpServletRequest request = ctx.getRequest();
        Object accessToken = request.getParameter("token"); //获取请求参数
        if (accessToken != null && !"".equals(accessToken)) {
            ctx.setSendZuulResponse(true);
            ctx.setResponseStatusCode(200);
            ctx.set("isSuccess", true); //设值，让下一个过滤器 获取到上一个过滤器的状态
        } else {
            log.warn("token is empty");
            ctx.setSendZuulResponse(false); //过滤该请求，不对其进行路由
            ctx.setResponseStatusCode(401); //返回错误代码
            ctx.set("isSuccess", false);
            try {
                ctx.getResponse().getWriter().write("token is empty");//返回错误内容
            } catch (Exception e) {
                // e.printStackTrace();
                return null;
            }
        }
        log.info("OK");
        return null;
    }
}
