package com.hand.gitconfigclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Configuration
@EnableAutoConfiguration
@RestController
@RefreshScope
public class HelloController {
    @Value("${hello}")
    private String hello;
    @Autowired
    //LoadBalancerClient loadBalancerClient;

    @GetMapping("/hello")
    // @RequestMapping("/hello")
    public String hello() {
        //  ServiceInstance instance = loadBalancerClient.choose("config-server");
        // return " port:" + instance.getPort() + "," + hello;
        return hello;
    }
}
